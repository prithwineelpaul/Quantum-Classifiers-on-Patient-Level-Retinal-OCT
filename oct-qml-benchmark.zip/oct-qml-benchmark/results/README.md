# Result files

The verification scripts and the analysis cells of notebook 02 read these files. Files produced by the reported runs
should be placed here exactly as the notebooks wrote them (same names).

| File | Written by | Used by |
|---|---|---|
| `split_manifest.json`, `split_summary.csv` | 01 / Cell 3, 02 / Cell 6 | `verify_split.py --manifest` |
| `cv_runs.csv`, `cv_tests.csv`, `data_efficiency.csv`, `final_test_metrics.csv`, `final_test_comparisons.csv`, `quantum_noise.csv`, `image_noise_robustness.csv`, `param_counts.csv`, `summary.json` | 01 (run A) | `verify_cv_tests.py`, paper |
| `benchmark_param_counts.csv`, `benchmark_cv_heads.csv`, `benchmark_cv_kernels.csv`, `benchmark_kernel_selected_params.csv`, `benchmark_cv_tests.csv`, `benchmark_kernel_concentration.csv`, `benchmark_geometric_difference.csv`, `benchmark_test_metrics.csv`, `benchmark_test_comparisons.csv`, `benchmark_verdicts.md` | 02 with `RUN_BENCHMARK = True` (run B) | `verify_cv_tests.py`, paper |
| `hw_inputs.npz` | 02 / Cell 22 | circuit angles, trained circuit weights, exact ⟨Y⟩ for the 300 images |
| `hw_heads_fold0_seed0.pt`, `hw_images.csv` | 02 / Cell 22 (`check`/`test` step) | the head and the image list that were sent to the QPU |
| `hw_bits_main.npy` | `ibm_run.py main` | raw measurement bits, 300 × 1024 × 20 |
| `hw_ev_mitigated.npy`, `hw_ev_std_mitigated.npy` | `ibm_run.py mitigated` | mitigated ⟨Y⟩ and their standard errors |
| `hw_info_main.json` (+ `hw_info_mitigated.json`) | `ibm_run.py` | backend, physical qubits, gate counts, calibration medians |
| `ibm_job_*.json` | `ibm_run.py` | job IDs and settings |
| `hw_results.csv`, `hw_summary.json`, `hw_mitigation_comparison.csv`, `hw_mitigation_tests.csv` | 02 / Cells 25, 26 | `verify_hardware.py` compares against these |
| `external_validation.csv`, `external_validation_tests.csv` | 02 / Cell 28 | paper |
| `environment_01.txt`, `environment_02.txt` | last cell of each notebook | software versions |

Large binaries that are not needed for verification (`backbone_*.pt`, `features.npz`, `ext_features_*.npz`,
`ext_head_ensembles.pt`) are excluded by `.gitignore`; they can be attached to a GitHub release or a Zenodo record.

`hw_info_main.json` is included already: it is the transpilation record of the unmitigated `ibm_kingston` run reported in the paper.
